// JavaScript for toggling the mobile navigation menu
const showMenu = (toggleId, navId) => {
  const toggle = document.getElementById(toggleId);
  const nav = document.getElementById(navId);

  if (toggle && nav) {
      toggle.addEventListener('click', () => {
          nav.classList.toggle('show');
      });
  }
}
showMenu('nav-toggle', 'nav-menu');

// JavaScript for changing sizes and colors of the sneaker
const sizes = document.querySelectorAll('.size__tallas');
const colors = document.querySelectorAll('.sneaker__color');
const sneakerImages = document.querySelectorAll('.sneaker__img');

function changeSize() {
  sizes.forEach(size => size.classList.remove('active'));
  this.classList.add('active');
}

function changeColor() {
  let primary = this.getAttribute('primary');
  let color = this.getAttribute('color');
  let sneakerColor = document.querySelector(`.sneaker__img[color="${color}"]`);

  colors.forEach(c => c.classList.remove('active'));
  this.classList.add('active');

  document.documentElement.style.setProperty('--primary', primary);

  sneakerImages.forEach(img => img.classList.remove('shows'));
  sneakerColor.classList.add('shows');
}

sizes.forEach(size => size.addEventListener('click', changeSize));
colors.forEach(color => color.addEventListener('click', changeColor));

// JavaScript for hiding/showing the navbar on scroll
const navbar = document.querySelector('.nav');

window.addEventListener('scroll', () => {
  const scrollPosition = window.scrollY;

  if (scrollPosition > 200) {
      navbar.classList.add('hide');
  } else {
      navbar.classList.remove('hide');
  }
});


