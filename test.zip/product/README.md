#  Responsive Product Card Landing Page
### BY TALO

<a href="https://alphaotuken.github.io/Responsive-Hover-Card/"><strong>➥ Live Demo</strong></a>

- Responsive Product Card Landing Page HTML CSS & JavaScript
- Contains color change animations.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

![preview img](/preview.png)

### Contact

If you want to contact with me you can reach me at [Twitter](https://www.twitter.com/taloisik).

### License

This project contains the MIT Licence 
