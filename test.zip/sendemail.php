<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    
    // Validate email
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $to = 'omkumar.coder@gmail.com'; // Your Gmail address
        $subject = 'New Subscription';
        $message = 'Email: ' . $email;
        $headers = 'From: yourwebsite@example.com' . "\r\n" .
                   'Reply-To: yourwebsite@example.com' . "\r\n" .
                   'X-Mailer: PHP/' . phpversion();

        // Send email
        if (mail($to, $subject, $message, $headers)) {
            echo 'Email sent successfully.';
        } else {
            echo 'Failed to send email.';
        }
    } else {
        echo 'Invalid email format.';
    }
}
?>
